#ifndef ID_TESTS_H
#define ID_TESTS_H

void add_id_tests(Suite *s);

#endif
